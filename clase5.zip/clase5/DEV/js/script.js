const productos = [
    { nombre: "Mochila de cuero", precio: 20, disponible: true, image: "../img/mochila.jpg" },
    { nombre: "Botas de Ninja", precio: 35, disponible: true, image: "../img/tabininja.jpg" },
    { nombre: "Espada de Madera", precio: 50, disponible: true, image: "../img/espada.webp" },
    { nombre: "Escudo de Hierro", precio: 150, disponible: false, image: "../img/escudo.jpg" }
];

productos.forEach(producto => {
    document.write('<div class="product-card">');
    document.write(`<img class="product-image" src="${producto.image}" alt="Foto de ${producto.nombre}">`);
    document.write(`<p><strong>Nombre:</strong> ${producto.nombre}</p>`);
    document.write(`<p><strong>Tipo de dato:</strong> ${typeof producto.nombre}</p>`);
    document.write('<hr>');
    document.write(`<p><strong>Precio:</strong> $${producto.precio}</p>`);
    document.write(`<p><strong>Tipo de dato:</strong> ${typeof producto.precio}</p>`);
    document.write('<hr>');
    document.write(`<p><strong>Disponible:</strong> ${producto.disponible ? 'Si' : 'No'}</p>`);
    document.write(`<p><strong>Tipo de dato:</strong> ${typeof producto.disponible}</p>`);
    document.write('</div>');
});
 
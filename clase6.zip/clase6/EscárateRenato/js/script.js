const productos = [
    { nombre: "Mochila de cuero", precio: 20, stock: 10, disponible: true, image: "../img/mochila.jpg" },
    { nombre: "Botas de Ninja", precio: 35, stock: 5, disponible: true, image: "../img/tabininja.jpg" },
    { nombre: "Espada de Madera", precio: 50, stock: 0, disponible: false, image: "../img/espada.webp" },
    { nombre: "Escudo de Hierro", precio: 150, stock: 2, disponible: true, image: "../img/escudo.jpg" },
    { nombre: "Armadura de Dragón", precio: 300, stock: 1, disponible: true, image: "../img/armadura.jpg" }
];

productos.forEach(producto => {
    document.write('<div class="product-card">');
    document.write(`<img class="product-image" src="${producto.image}" alt="Foto de ${producto.nombre}">`);
    document.write(`<p><strong>Nombre:</strong> ${producto.nombre}</p>`);
    document.write('<hr>');
    document.write(`<p><strong>Precio:</strong> $${producto.precio}</p>`);
    document.write('<hr>');
    document.write(`<p><strong>Disponible:</strong> ${producto.disponible ? 'Si' : 'No'}</p>`);
    if (producto.stock === 0) {
        document.write("<p><strong> Producto agotado </strong></p>");
    } else if (producto.stock < 5) {
        document.write("<p><strong> Stock bajo </strong></p>");
    } else {
        document.write("<p><strong> Producto disponible </strong></p>");
    }
    document.write('</div>');
});

const productoMasCaro = productos.reduce((max, producto) =>
    producto.precio > max.precio ? producto : max
);

document.write('<div class="product-card" style="border: 3px solid gold; background-color: #fffacd;">');
document.write('<h2>⭐ Producto Más Caro ⭐</h2>');
document.write(`<img class="product-image" src="${productoMasCaro.image}" alt="Foto de ${productoMasCaro.nombre}">`);
document.write(`<p><strong>Nombre:</strong> ${productoMasCaro.nombre}</p>`);
document.write(`<p><strong>Precio:</strong> $${productoMasCaro.precio}</p>`);
document.write('</div>');

const productosConProblema = productos.filter(producto => 
    producto.stock === 0 || producto.stock < 5
).length;
document.write(`<p><strong>Total de productos:</strong> ${productos.length}</p>`);
document.write(`<p><strong>Productos disponibles:</strong> ${productos.filter(producto => producto.disponible && producto.stock > 0).length}</p>`);
document.write(`<p><strong>Productos agotados o con bajo stock:</strong> ${productosConProblema}</p>`);
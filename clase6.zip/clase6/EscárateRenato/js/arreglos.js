let frutas = ["manzana", "pera", "naranja", "uva", "kiwi", "manzana"];

document.write("<p><strong> Arreglo de frutas: </strong>" + frutas.join(", ") + "</p>");
document.write("<p><strong> Primer elemento: </strong>" + frutas[0] + "</p>");
document.write("<p><strong> Segundo elemento: </strong>" + frutas[1] + "</p>");
document.write("<p><strong> Tercer elemento: </strong>" + frutas[2] + "</p>");
document.write("<p><strong> Cuarto elemento: </strong>" + frutas[3] + "</p>");
document.write("<p><strong> Quinto elemento: </strong>" + frutas[4] + "</p>");
document.write("<p><strong> Longitud del arreglo: </strong>" + frutas.length + "</p>");


let notas = [6.5, 4.0, 5.7, 5.0, 3.2];
let suma = 0;
for(let i = 0; i < notas.length; i++){
    suma += notas[i];
}
let promedio = suma / notas.length;

document.write("<p><strong> Promedio: </strong>" + promedio.toFixed(2) + "</p>");
if(promedio >= 4.0){
    document.write("<p><strong> Aprobado </strong></p>");
} else {
    document.write("<p><strong> Reprobado </strong></p>");
}

document.write("<hr>");

for(let i = 0; i < frutas.length; i++){
    document.write("<p><strong> Fruta " + (i+1) + ": </strong>" + frutas[i] + "</p>");
}

let contador = 0;
for(let i = 0; i < frutas.length; i++){
    if(frutas[i] === "manzana"){
        contador++;        
    }
}
document.write("<p><strong> Número de manzanas: </strong>" + contador + "</p>");

contador = 0;
while(contador <= 5){
    document.write("<p><strong> Contador: </strong>" + contador + "</p>");
    contador++;
}